package com.example.mypc.intent;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void next(View view) {

        Intent i = new Intent(this,SecondActivity.class);
        startActivity(i);


    }

    public void openBrowser(View view) {
        EditText et;
        et =findViewById(R.id.url_edit);
        String url_text = et.getText().toString();
       Intent in = new Intent(Intent.ACTION_VIEW, Uri.parse("http://"+url_text));
       startActivity(in);
    }

    public void openDailer(View view) {
        EditText et;
        et=findViewById(R.id.number_edit);
        String num=et.getText().toString();
        Intent in = new Intent(Intent.ACTION_DIAL,Uri.parse("tel:"+num));
        startActivity(in);
    }



        }
